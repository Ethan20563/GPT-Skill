"""Find source headings and optionally render one original PDF page."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--query', default='')
    pages = parser.add_mutually_exclusive_group()
    pages.add_argument('--page', type=int, help='One-based PDF page')
    pages.add_argument('--book-page', type=int, help='Arabic printed page')
    parser.add_argument('--source', type=Path, help='Override the local source PDF path')
    parser.add_argument('--verify', action='store_true', help='Check the recorded SHA-256')
    parser.add_argument('--render', type=Path, help='Save one page to this PNG path')
    parser.add_argument('--renderer', type=Path, help='Explicit pdftoppm executable')
    args = parser.parse_args()
    data = json.loads((ROOT / 'references' / 'source-index.json').read_text(encoding='utf8'))
    if args.query:
        matches = [s for s in data['sections'] if args.query.casefold() in s['title'].casefold()]
        for section in matches:
            print(f"PDF {section['pdf_page']} | {section['title']}")
        if not matches:
            print('No matching heading. Try a shorter keyword.')
    page = args.page
    if args.book_page is not None:
        if not 1 <= args.book_page <= data['last_arabic_page']:
            parser.error('Printed page is outside the recorded Arabic page range.')
        page = args.book_page + data['arabic_page_offset']
    if page is not None and not 1 <= page <= data['pdf_pages']:
        parser.error('PDF page is outside the source page range.')
    if args.render is None and not args.verify:
        if page is not None:
            print(f'PDF page: {page}')
        return
    source = args.source or Path(data['source_file'])
    if not source.is_file():
        parser.error('Source PDF is unavailable. Provide --source with its new path.')
    if args.verify:
        digest = hashlib.sha256()
        with source.open('rb') as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(block)
        if digest.hexdigest() != data['sha256']:
            parser.error('Source fingerprint does not match this edition/file.')
        print('Source fingerprint verified.')
    if args.render is None:
        return
    if page is None:
        parser.error('--render requires --page or --book-page.')
    renderer = args.renderer or shutil.which('pdftoppm')
    if renderer is None and os.name == 'nt':
        candidate = Path.home() / '.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
        if candidate.is_file():
            renderer = candidate
    if renderer is None:
        parser.error('pdftoppm is unavailable. Install Poppler or provide --renderer.')
    output = args.render.resolve()
    if output.suffix.lower() != '.png':
        parser.error('--render must name a PNG file.')
    output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([str(renderer), '-f', str(page), '-l', str(page), '-r', '150',
                    '-singlefile', '-png', str(source), str(output.with_suffix(''))], check=True)
    if not output.is_file():
        parser.error('Renderer completed without producing the expected PNG.')
    print(output)


if __name__ == '__main__':
    main()
