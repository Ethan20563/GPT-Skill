"""Local-only search, reading and page-image verification for the five volumes."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]

def manifest():
    return json.loads((ROOT/'references/sources.json').read_text(encoding='utf-8'))

def database():
    return sqlite3.connect('file:'+str(ROOT/'references/handbook.sqlite3').replace('\\','/')+'?mode=ro',uri=True)

def emit(obj):
    print(json.dumps(obj,ensure_ascii=False,indent=2))

def compact(s):
    return re.sub(r'\s+','',s)

def row_info(row, include_text=True):
    result={'volume':row[0],'pdf_page':row[1],'printed_page':row[2],'part':row[3],
            'citation':f'《机械设计手册》第6版，第{row[0]}卷，PDF第{row[1]}页'+(f'，印刷页换算{row[2]}' if row[2] else '')}
    if include_text:result['ocr_text']=row[4]
    return result

def search(args):
    terms=[compact(x) for x in args.keywords if compact(x)]
    if not terms:raise SystemExit('Provide at least one keyword.')
    if args.limit<1 or args.limit>20:raise SystemExit('limit must be 1..20')
    clauses=['instr(compact,?)>0' for _ in terms]
    values=list(terms)
    if args.volume:
        clauses.append('volume=?');values.append(args.volume)
    if args.part:
        clauses.append('part=?');values.append(args.part)
    if not args.all_pages:
        clauses.append('part IS NOT NULL')
    where=(' OR ' if args.any else ' AND ').join(clauses[:len(terms)])
    if len(clauses)>len(terms):where='('+where+') AND '+' AND '.join(clauses[len(terms):])
    with database() as db:
        rows=db.execute('SELECT volume,pdf_page,printed_page,part,text,compact FROM pages WHERE '+where,values).fetchall()
    rows.sort(key=lambda r:(-sum(min(r[5].count(t),12) for t in terms),r[0],r[1]))
    results=[]
    for row in rows[:args.limit]:
        record=row_info(row,False)
        lines=row[4].splitlines()
        hit_indices=[i for i,s in enumerate(lines) if any(t in compact(s) for t in terms)]
        snippets=[]
        for i in hit_indices[:3]:snippets.append('\n'.join(lines[max(0,i-1):min(len(lines),i+3)]))
        record['snippets']=snippets
        results.append(record)
    emit({'keywords':terms,'matching_pages':len(rows),'results':results,'quality_note':'OCR用于定位；公式、表格对应关系、尺寸与标准编号须核对原图。'})

def read(args):
    if not 1<=args.count<=8:raise SystemExit('count must be 1..8')
    with database() as db:
        rows=db.execute('SELECT volume,pdf_page,printed_page,part,text FROM pages WHERE volume=? AND pdf_page>=? AND pdf_page<? ORDER BY pdf_page',(args.volume,args.page,args.page+args.count)).fetchall()
    if len(rows)!=args.count:raise SystemExit('Requested page range is absent or outside the source.')
    emit({'pages':[row_info(r) for r in rows],'quality_note':'这是机器识别文本，不是经人工校对的公式或参数表。'})

def render(args):
    from pypdf import PdfReader
    record=next(s for s in manifest()['sources'] if s['volume']==args.volume)
    source=Path(record['path'])
    if not source.is_file():raise SystemExit('原书路径失效，请更新 references/sources.json 中的 path。')
    if not 1<=args.page<=record['pages']:raise SystemExit('PDF page is outside the source.')
    with source.open('rb') as handle:
        reader=PdfReader(handle)
        page=reader.pages[args.page-1]
        images=list(page.images)
        if not images:raise SystemExit('This page has no extractable scan image.')
        largest=max(images,key=lambda im:im.image.width*im.image.height)
        output=Path(args.out).resolve()
        output.parent.mkdir(parents=True,exist_ok=True)
        largest.image.convert('RGB').save(output)
    emit({'volume':args.volume,'pdf_page':args.page,'image':str(output),'source':str(source),'note':'原PDF最大扫描图像；公式核对请查看此图，必要时同时打开原PDF。'})

def outline(args):
    data=json.loads((ROOT/'references/parts.json').read_text(encoding='utf-8'))
    emit([p for p in data if args.part is None or p['part']==args.part])

def check(args):
    data=manifest()
    with database() as db:
        counts=dict(db.execute('SELECT volume,count(*) FROM pages GROUP BY volume').fetchall())
        failed=db.execute('SELECT volume,pdf_page FROM pages WHERE ok=0').fetchall()
    sources=[]
    for source in data['sources']:
        path=Path(source['path'])
        result={'volume':source['volume'],'expected':source['pages'],'indexed':counts.get(source['volume'],0),'source_exists':path.exists()}
        if args.hash and path.exists():
            with path.open('rb') as f:result['sha256_matches']=hashlib.file_digest(f,'sha256').hexdigest()==source['sha256']
        sources.append(result)
    emit({'sources':sources,'failed_pages':failed,'extraction':data['extraction'],'complete':not failed and all(s['expected']==s['indexed'] for s in sources)})

def main():
    if hasattr(sys.stdout,'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8',errors='replace')
    parser=argparse.ArgumentParser(description=__doc__)
    subs=parser.add_subparsers(dest='command',required=True)
    p=subs.add_parser('search');p.add_argument('keywords',nargs='+');p.add_argument('--volume',type=int,choices=range(1,6));p.add_argument('--part',type=int,choices=range(1,24));p.add_argument('--limit',type=int,default=5);p.add_argument('--any',action='store_true');p.add_argument('--all-pages',action='store_true');p.set_defaults(func=search)
    p=subs.add_parser('read');p.add_argument('--volume',type=int,required=True,choices=range(1,6));p.add_argument('--page',type=int,required=True);p.add_argument('--count',type=int,default=1);p.set_defaults(func=read)
    p=subs.add_parser('render');p.add_argument('--volume',type=int,required=True,choices=range(1,6));p.add_argument('--page',type=int,required=True);p.add_argument('--out',required=True);p.set_defaults(func=render)
    p=subs.add_parser('outline');p.add_argument('--part',type=int,choices=range(1,24));p.set_defaults(func=outline)
    p=subs.add_parser('check');p.add_argument('--hash',action='store_true');p.set_defaults(func=check)
    args=parser.parse_args();args.func(args)

if __name__=='__main__':main()
